/***************************************************************************
 * linked.c
 *
 * Computer Science 50
 * Problem Set Mini-college
 *
 * Implements basic operations on Linked Lists.
 *
 * Usage: linked
 *
 *
***************************************************************************/
 
#define _XOPEN_SOURCE 500

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// constants

// prototypes
void greet(void);       // Say something nice
void menu(void);        // Print the menu

void add(void);         // Add node to list
void delete(void);      // Delete node from list

void traverse();        // Print all the datafields from all nodes
void swap(void);        // Swap two nodes in the list

// Linked list, define the structure of the node
typedef struct node
{
    int n;
    int getal;
    struct node *next;
}
node;

// linked list, define head of list
node *head = NULL;

int
main(int argc, char *argv[])
{
    // greet user with instructions
    greet();
    
    // Print menu
    menu();

    // ensure proper usage
    if (argc != 1)
    {
        printf("Usage: Linked\n");
        return 1;
    }
 
    // 
    while (true)
    {
        // prompt for action
        printf("Operation: ");
        
        char command = GetChar();
        
        // Delete a node
        if(command == '1')
        {
            delete();
        }
        
        // Find a node
        if(command == '2')
        {
            add();
        }
        
        // Insert a node
        if(command == '3')
        {
            swap();
        }
        
        // Traverse the list
        if(command == '4')
        {
            traverse();
        }
        
        // quit
        if(command == '5')
        {
            return 0;
        }
   }
       
}



void
greet(void)
{

    printf("Basic operations on linked lists\n");
}

void
add(void)
{
    // Add node to the end of the list
    printf("Geef getal : \n");
    printf("Add node (to be implemented) \n");
        
}


void
delete(void)
{
    // Delete the last node in the list
    printf("Delete last node (to be implemented )\n");
        
}


void
traverse(void)
{
    // Print all nodes in the list
    printf("Print all nodes in list (to be implemented) \n");
        
}


void
swap(void)
{
    // Swap two nodes
    printf("give two nodes to swap (to be implemented)\n");
    printf("Node A : \n");
    printf("Node B : \n");
    
}

void 
menu(void)
{
    // Print menu
    printf("    MENU\n");
    printf("\n");
    printf("1 - delete\n");
    printf("2 - add\n");
    printf("3 - swap\n");
    printf("4 - print\n");
    printf("5 - quit\n");

}


